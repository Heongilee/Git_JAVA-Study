
public class JS01_02_15012970 {
	public static void main(String[] args) {
		System.out.println("Sorry~");
		System.out.println("��վ �̾��մϴ�~~");
	}
}
